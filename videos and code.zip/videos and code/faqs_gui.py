import streamlit as st
import re
import string
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# FAQ Data
faq_data = {
    "What is your return policy?": "We offer a 30-day return policy on all items.",
    "How do I track my order?": "You can track your order from your profile under 'My Orders'.",
    "Do you ship internationally?": "Yes, we ship worldwide with additional shipping charges.",
    "How can I contact support?": "You can email us at support@example.com or call 123-456-7890.",
    "What payment methods are accepted?": "We accept Visa, MasterCard, PayPal, and bank transfers."
}

# Simple text cleaner
def preprocess(text):
    text = text.lower()
    text = re.sub(r"\d+", "", text)  # Remove numbers
    text = text.translate(str.maketrans("", "", string.punctuation))  # Remove punctuation
    text = text.strip()
    return text

# Preprocess all questions
questions = list(faq_data.keys())
answers = list(faq_data.values())
processed_questions = [preprocess(q) for q in questions]

# Vectorize using TF-IDF
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(processed_questions)

# Streamlit UI
st.title("🤖 FAQ Chatbot")

user_input = st.text_input("Ask your question:")

if user_input:
    input_processed = preprocess(user_input)
    input_vector = vectorizer.transform([input_processed])
    similarity_scores = cosine_similarity(input_vector, tfidf_matrix)
    best_match_idx = similarity_scores.argmax()
    best_score = similarity_scores[0][best_match_idx]

    if best_score > 0.3:
        st.success(f"Answer: {answers[best_match_idx]}")
    else:
        st.warning("❓ Sorry, I couldn't understand the question. Try rephrasing.")
