import streamlit as st
from deep_translator import GoogleTranslator
import pyttsx3

# Set page config
st.set_page_config(page_title="Language Translator", page_icon="🌍")

# Title
st.title("🌍 Language Translation Tool")

# Input text
source_text = st.text_area("Enter text to translate:", height=150)

# Language options
languages = {
    "English": "en",
    "Urdu": "ur",
    "French": "fr",
    "Spanish": "es",
    "Arabic": "ar",
    "German": "de",
    "Chinese (Simplified)": "zh-CN",
    "Hindi": "hi"
}

col1, col2 = st.columns(2)

with col1:
    src_lang = st.selectbox("Source Language", list(languages.keys()), index=0)
with col2:
    tgt_lang = st.selectbox("Target Language", list(languages.keys()), index=1)

# Translate button
if st.button("🔄 Translate"):
    if source_text.strip() == "":
        st.warning("Please enter text to translate.")
    else:
        # Perform translation
        result = GoogleTranslator(
            source=languages[src_lang],
            target=languages[tgt_lang]
        ).translate(source_text)

        st.success("Translation Complete!")
        st.text_area("Translated Text", value=result, height=150, key="translated")

        # Show copyable code block
        st.code(result, language="text")

        # Download button
        st.download_button("📋 Copy Result", data=result, file_name="translation.txt")

        # Text-to-speech
        if st.button("🔊 Speak Translated Text"):
            engine = pyttsx3.init()
            engine.say(result)
            engine.runAndWait()
